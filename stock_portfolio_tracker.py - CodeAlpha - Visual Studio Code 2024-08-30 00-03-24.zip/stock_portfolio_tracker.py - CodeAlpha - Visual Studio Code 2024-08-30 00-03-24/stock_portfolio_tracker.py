import yfinance as yf

class StockPortfolio:
    def __init__(self):
        self.portfolio = {}
        
    def add_stock(self, symbol, quantity):
        if symbol in self.portfolio:
            self.portfolio[symbol] += quantity
        else:
            self.portfolio[symbol] = quantity
    
    def remove_stock(self, symbol, quantity):
        if symbol in self.portfolio:
            if quantity >= self.portfolio[symbol]:
                del self.portfolio[symbol]
            else:
                self.portfolio[symbol] -= quantity
        else:
            print(f"Stock {symbol} not found in portfolio.")
    
    def get_stock_price(self, symbol):
        stock = yf.Ticker(symbol)
        price = stock.history(period='1d')['Close'].iloc[-1]
        return price
    
    def display_portfolio(self):
        print("\nCurrent Portfolio:")
        total_value = 0.0
        for symbol, quantity in self.portfolio.items():
            price = self.get_stock_price(symbol)
            value = price * quantity
            total_value += value
            print(f"{symbol}: {quantity} shares @ ${price:.2f} each, Total Value: ${value:.2f}")
        
        print(f"\nTotal Portfolio Value: ${total_value:.2f}")

def main():
    portfolio = StockPortfolio()
    
    while True:
        print("\nStock Portfolio Tracker")
        print("1. Add Stock")
        print("2. Remove Stock")
        print("3. Display Portfolio")
        print("4. Exit")
        
        choice = input("Choose an option (1-4): ")
        
        if choice == '1':
            symbol = input("Enter stock symbol (e.g., AAPL): ").upper()
            quantity = int(input("Enter quantity of shares: "))
            portfolio.add_stock(symbol, quantity)
            print(f"Added {quantity} shares of {symbol}.")
        
        elif choice == '2':
            symbol = input("Enter stock symbol (e.g., AAPL): ").upper()
            quantity = int(input("Enter quantity of shares to remove: "))
            portfolio.remove_stock(symbol, quantity)
            print(f"Removed {quantity} shares of {symbol}.")
        
        elif choice == '3':
            portfolio.display_portfolio()
        
        elif choice == '4':
            print("Exiting...")
            break
        
        else:
            print("Invalid choice. Please select a valid option.")

if __name__ == "__main__":
    main()